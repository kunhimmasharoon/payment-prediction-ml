import axios from "axios";
export const getData = async()=>{
    let response = await axios.get('http://localhost:8081/project/DataFetch');
    let data =response.data.Details;
    data.map(val=> val["name"]=val.sl_no)
    // data.map((detail,index) =>({...detail, "id": index}))
   return data;
}

