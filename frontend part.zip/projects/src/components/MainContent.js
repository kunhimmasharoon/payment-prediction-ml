import React from "react";
import "../css/MainContent.css";

// Icons
import SearchPic from "../assets/search.png";
import ClosePic from "../assets/close.png";
import AddIcon from "../assets/add.png";
import EditIcon from "../assets/edit.png";
import DeleteIcon from "../assets/delete.png";

// Components
import GridTable from "./GridTable";

const MainContent = () => {
  return (
    <main>
        {/* // Menu */}
      <div className="menu">
        <button className="btn btn-secondary">Predict</button>
        <button className="btn btn-simple">Analytics</button>
        <button className="btn btn-simple">Adv. Search</button>

        <button className="btn btn-primary" style={{ marginLeft: "auto" }}>
          <img src={AddIcon} alt="add-logo" />
          Add
        </button>
        <button className="btn btn-primary">
          <img src={EditIcon} alt="edit-logo" />
          Edit
        </button>
        <button className="btn btn-primary">
          <img src={DeleteIcon} alt="delete-logo" />
          Delete
        </button>
        <div className="search-box">
          <img alt="search-logo" draggable="false" src={SearchPic} />
          <input type="text" placeholder="Search by Customer No" />
          <img alt="close-logo" src={ClosePic} draggable="false" />
        </div>
      </div>

        {/* // Table */}
      <GridTable/>

      <div className="pagination">
          <p>Page</p>
          <input type="number"/>

          <p style={{marginLeft:"auto"}}>Rows per page</p>
          <select style={{marginRight:"10px"}}>
              <option value="10">10</option>
              <option value="10">50</option>
              <option value="10">100</option>
              <option value="10">150</option>
              <option value="10">300</option>
          </select>

          <button className="btn">&lt;</button>
          <p><span>1</span> - <span>50</span> of <span>250</span></p>
          <button className="btn">&gt;</button>
      </div>
    </main>
  );
};

export default MainContent;
