import React from 'react';
import '../css/ModalWindow.css';
import CloseLogo from '../assets/close.png';

const ModalWindow = () => {
    return (
        <div className="modal-window">
            <div className="modal">
                <div className="modal-heading">
                    <h2>Advance Search</h2>
                    <img alt="" src={CloseLogo}/>
                </div>
                <div className="modal-body">

                </div>
            </div>
        </div>
    );
};

export default ModalWindow;