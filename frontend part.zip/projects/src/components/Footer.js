import React from 'react';
import '../css/Footer.css';

const Footer = () => {
    return (
        <footer>
          <span>Privacy Policy</span> | © 2022 HighRadius Corporation. All rights reserved
        </footer>
    );
};

export default Footer;