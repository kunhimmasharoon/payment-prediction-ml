import React from 'react';
import '../css/Navbar.css';
import HighRadiusLogo from '../assets/highradiuslogo.svg';
import ABCLogoFull from   '../../src/assets/ABCLogoFull.svg';


const Navbar = () => {
    return (
        <nav>
           <div className="ABCLogoFull">
            <img src={ABCLogoFull} alt="ABCLogoFull"/>
            </div>
            
            <div className="highradius-logo">
            <img src={HighRadiusLogo} alt="High Radius"/>
            </div>
            <div className="user-auth">
                Invoice list
            </div>
        </nav>
    );
};

export default Navbar;