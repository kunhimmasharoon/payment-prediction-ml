import React from 'react';

// Components 
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MainContent from './components/MainContent';
import ModalWindow from './components/ModalWindow';

const App = () => {
  return (
    <>
      <Navbar/>
      <MainContent/>
      <Footer/>

      {/* // additional */}
      {/*// <ModalWindow/> */}
    </>
  );
};

export default App;