package conn.hrc;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import H2Hjdbc.Jdbc;

/**
 * Servlet implementation class Deletedetails
 */
@WebServlet("/Deletedetails")
public class Deletedetails extends HttpServlet {
	private static final long serialVersionUID = 4L;
	static final String dbDriver="com.mysql.jdbc.Driver";
	static final String dbURL= "jdbc:mysql://localhost:3306/grey_goose";

	static final String username="root";
	static final String password="Yash123@";
   
    public Deletedetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
            //Connecting JDBC with SQL
			Connection con = DriverManager.getConnection(dbURL, username, password);
			//Creating an PreparedStatement to edit data into an database
			String invoice = request.getParameter("doc_id");
			PreparedStatement ps = con.prepareStatement("DELETE FROM winter_internship WHERE doc_id=\""+invoice+"\"");
			ps.executeUpdate();
			System.out.println( invoice);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		response.getWriter().write("DELETED");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}