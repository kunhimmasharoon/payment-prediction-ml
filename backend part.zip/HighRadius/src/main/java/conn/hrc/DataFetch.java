package conn.hrc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import H2Hjdbc.Jdbc;
import H2Hpojo.H2Hpojodetails;

/**
 * Servlet implementation class DataFetch
 */
@WebServlet("/DataFetch")
public class DataFetch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataFetch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//list of H2Hdetails
		ArrayList<H2Hpojodetails> data =new ArrayList<H2Hpojodetails>();
		
		HashMap<Object,Object> r=new HashMap<Object,Object>();
		try {
			Connection con =Jdbc.getConnection();
					//statement
					Statement st =con.createStatement();
					//queryExecution
					String Query="select * from winter_internship";
					ResultSet result =st.executeQuery(Query);
										
					while(result.next()) {
						System.out.println("sl_no :"+result.getLong("sl_no"));
						System.out.println("business_code:"+result.getString("business_code"));
						System.out.println("cust_number:"+result.getLong("cust_number"));
						System.out.println("clear_date:"+result.getString("clear_date"));
						System.out.println("buisness_year:"+result.getString("buisness_year"));
						System.out.println("doc_id:"+result.getLong("doc_id"));
						System.out.println("posting_date:"+result.getString("posting_date"));
						System.out.println("document_create_date:"+result.getString("document_create_date"));
						System.out.println("document_create_date1:"+result.getString("document_create_date1"));
						System.out.println("due_in_date:"+result.getString("due_in_date"));
						System.out.println("invoice_currency:"+result.getString("invoice_currency"));
						System.out.println("document_type:"+result.getString("document_type"));
						System.out.println("posting_id:"+result.getLong("posting_id"));
						System.out.println("area_business:"+result.getString("area_business"));
						System.out.println("total_open_amount:"+result.getLong("total_open_amount"));
						System.out.println("baseline_create_date:"+result.getString("baseline_create_date"));
						System.out.println("cust_payment_terms:"+result.getString("cust_payment_terms"));
						System.out.println("invoice_id:"+result.getLong("invoice_id"));
						System.out.println("isOpen:"+result.getString("isOpen"));
						System.out.println("aging_bucket:"+result.getString("aging_bucket"));		
						System.out.println("is_deleted:"+result.getLong("is_deleted"));
						
						H2Hpojodetails h2hdetails = new H2Hpojodetails();
						h2hdetails.setSl_no(result.getLong("sl_no"));
						h2hdetails.setBusiness_code(result.getString("business_code"));
						h2hdetails.setCust_number(result.getLong("cust_number"));
						h2hdetails.setClear_date(result.getString("clear_date"));
						h2hdetails.setBusiness_year(result.getString("buisness_year"));
						h2hdetails.setDoc_id(result.getLong("doc_id"));
						h2hdetails.setPosting_date(result.getString("posting_date"));
						h2hdetails.setDocument_create_date(result.getString("document_create_date"));
						h2hdetails.setDocument_create_date1(result.getString("document_create_date1"));
						h2hdetails.setDue_in_date(result.getString("due_in_date"));
						h2hdetails.setInvoice_currency(result.getString("invoice_currency"));
						h2hdetails.setDocument_type(result.getString("document_type"));
						h2hdetails.setPosting_id(result.getLong("posting_id"));
						h2hdetails.setArea_business(result.getString("area_business"));
						h2hdetails.setTotal_open_amount(result.getLong("total_open_amount"));
						h2hdetails.setBaseline_create_date(result.getString("baseline_create_date"));
						h2hdetails.setCust_payment_terms(result.getString("cust_payment_terms"));
						h2hdetails.setInvoice_id(result.getLong("invoice_id"));
						h2hdetails.setAging_bucket(result.getString("aging_bucket"));
						h2hdetails.setIs_deleted(result.getLong("is_deleted"));
						
						data.add(h2hdetails);
						
						
						
						}
						//preparing Json
						//String reJson =new Gson().toJson(data);
						
						//setting up  content ype json
						//response.setContentType("application/json");
						//setting up code
						
						r.put("Details", data);	
						String resJson = new Gson().toJson(r);	 				
						// setting up the content-type header
						response.setContentType("application/json");
						response.setHeader("Access-Control-Allow-Origin", "*");
						// setting up status code 200 - OK
						response.setStatus(200);

						//sending response
						response.getWriter().append(resJson);
						
									
				   }
					
					catch(Exception e) {
					System.out.println(e);}
				}
	
		

		//response.getWriter().append("Served at: ").append(request.getContextPath());
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		try {
//			Connection conn=getConnection();
//			
//			// statement
//			java.sql.Statement st = conn.createStatement();
//			
//			ClassDetails test=new Gson().fromJson(request.getReader(),ClassDetails.class);
//			System.out.println(test.getBusiness_code());
//			System.out.println(test.getCust_number());
//			System.out.println(test.getClear_date());
//			System.out.println(test.getBuisness_year());
//			System.out.println(test.getDoc_id());
//			System.out.println(test.getPosting_date());
//			System.out.println(test.getDocument_create_date());
//			System.out.println(test.getDue_in_date());
//			System.out.println(test.getInvoice_currency());
//			System.out.println(test.getDocument_type());
//			System.out.println(test.getPosting_id());
//			System.out.println(test.getTotal_open_amount());
//			System.out.println(test.getBaseline_create_date());
//			System.out.println(test.getCust_payment_terms());
//			System.out.println(test.getInvoice_id());
//			
//			
//			
//			String query ="INSERT INTO winter_internship(business_code,cust_number,clear_date,buisness_year,doc_id,posting_date,document_create_date,due_in_date,invoice_currency,Document_type,posting_id,total_open_amount,baseline_create_date,cust_payment_terms,invoice_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//		    PreparedStatement ps=conn.prepareStatement(query);
//		    ps.setString(1, test.getBusiness_code());
//		    ps.setInt(2, test.getCust_number());
//		    ps.setString(3, test.getClear_date());
//		    ps.setInt(4, test.getBuisness_year());
//		    ps.setString(5, test.getDoc_id());
//		    ps.setString(6, test.getPosting_date());
//		    ps.setString(7, test.getDocument_create_date());
//		    ps.setString(8, test.getDue_in_date());
//		    ps.setString(9, test.getInvoice_currency());
//		    ps.setString(10, test.getDocument_type());
//		    ps.setInt(11, test.getPosting_id());
//		    ps.setDouble(12, test.getTotal_open_amount());
//		    ps.setString(13, test.getBaseline_create_date());
//		    ps.setString(14, test.getCust_payment_terms());
//		    ps.setInt(15, test.getInvoice_id());
//		   
//		    
//		    
//		    int result=ps.executeUpdate();
//		    
//		    //setting up content type header
//		    response.setContentType("application/json");
//		    
//		    if(result >0) {
//		    	//status code
//		    	response.setStatus(201);
//		    	response sucessResponse=new response();
//		    	sucessResponse.setStatus("data added");
//		    	sucessResponse.setSucess(true);
//		    	response.getWriter().write(new Gson().toJson(sucessResponse));
//		    }
//		    else {
//		    	response.setStatus(500);
//	    	response failureResponse=new response();
//	    	failureResponse.setStatus("data insertion failed");
//	    	failureResponse.setSucess(false);
//	    	response.getWriter().write(new Gson().toJson(failureResponse));
//		    }	
//		}catch (Exception e) {
//			System.out.println(e);
//	}
//
//	}
//}  
		doGet(request, response);}}
	