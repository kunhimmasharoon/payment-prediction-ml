package conn.hrc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Editdetails
 */
@WebServlet("/Editdetails")
public class Editdetails extends HttpServlet {
		private static final long serialVersionUID = 3L;
	static final String dbDriver="com.mysql.jdbc.Driver";
	static final String dbURL="jdbc:mysql://localhost:3306/";
	static final String dbname="grey_goose";
	static final String username="root";
	static final String password="Yash123@";
   
    public Editdetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
            //Connecting JDBC with SQL
			Connection con = DriverManager.getConnection(dbURL+dbname, username, password);
			//Creating an PreparedStatement to edit data into an database
			String invoice_currency = request.getParameter("invoice_currency");
			String custpayment_terms = request.getParameter("cust_payment_terms");
			PreparedStatement ps = con.prepareStatement("UPDATE winter_internship SET invoice_currency=\""+invoice_currency+"\",cust_payment_terms=\""+custpayment_terms+"\" WHERE doc_id=\""+invoice_currency+"\"");
			System.out.println(ps);
			ps.executeUpdate();
			System.out.println(invoice_currency);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		response.getWriter().write("UPDATED");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}