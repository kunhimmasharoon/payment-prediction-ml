package H2Hjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.google.gson.Gson;

import H2Hpojo.H2Hpojodetails;



public class Jdbc {
	public static Connection getConnection(){
		
	Connection con =null;
	
	try {
		//loading driver
		Class.forName("com.mysql.jdbc.Driver");
	
		//making a connection
		 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose","root","Yash123@");
	}catch(Exception e) {
		System.out.println(e);
	}
	return con;}
	
		public static ArrayList <H2Hpojodetails>getAlldata(){
	    //list of H2Hpojodetails
		ArrayList<H2Hpojodetails> data =new ArrayList<H2Hpojodetails>();
		//statement
		try {
			Connection con=Jdbc.getConnection();
			PreparedStatement ps =con.prepareStatement("select * from winter_internship");
			ResultSet result=ps.executeQuery();
		//Statement st= con.createStatement();
		//query execution
		//String query="SELECT * FROM winter_internship";
		//result
		//ResultSet result =st.executeQuery(query);
		while(result.next()) {
			/*System.out.println("sl_no :"+result.getLong("sl_no"));
			System.out.println("business_code:"+result.getString("business_code"));
			System.out.println("cust_number:"+result.getLong("cust_number"));
			System.out.println("clear_date:"+result.getString("clear_date"));
			System.out.println("buisness_year:"+result.getString("buisness_year"));
			System.out.println("doc_id:"+result.getLong("doc_id"));
			System.out.println("posting_date:"+result.getString("posting_date"));
			System.out.println("document_create_date:"+result.getString("document_create_date"));
			System.out.println("document_create_date1:"+result.getString("document_create_date1"));
			System.out.println("due_in_date:"+result.getString("due_in_date"));
			System.out.println("invoice_currency:"+result.getString("invoice_currency"));
			System.out.println("document_type:"+result.getString("document_type"));
			System.out.println("posting_id:"+result.getLong("posting_id"));
			System.out.println("area_business:"+result.getString("area_business"));
			System.out.println("total_open_amount:"+result.getLong("total_open_amount"));
			System.out.println("baseline_create_date:"+result.getString("baseline_create_date"));
			System.out.println("cust_payment_terms:"+result.getString("cust_payment_terms"));
			System.out.println("invoice_id:"+result.getLong("invoice_id"));
			System.out.println("isOpen:"+result.getString("isOpen"));
			System.out.println("aging_bucket:"+result.getString("aging_bucket"));		
			System.out.println("is_deleted:"+result.getLong("is_deleted"));*/
			
			H2Hpojodetails h2hdetails = new H2Hpojodetails();
			
			h2hdetails.setSl_no(result.getLong("sl_no"));
			h2hdetails.setBusiness_code(result.getString("business_code"));
			h2hdetails.setCust_number(result.getLong("cust_number"));
			h2hdetails.setClear_date(result.getString("clear_date"));
			h2hdetails.setBusiness_year(result.getString("buisness_year"));
			h2hdetails.setDoc_id(result.getLong("doc_id"));
			h2hdetails.setPosting_date(result.getString("posting_date"));
			h2hdetails.setDocument_create_date(result.getString("document_create_date"));
			h2hdetails.setDocument_create_date1(result.getString("document_create_date1"));
			h2hdetails.setDue_in_date(result.getString("due_in_date"));
			h2hdetails.setInvoice_currency(result.getString("invoice_currency"));
			h2hdetails.setDocument_type(result.getString("document_type"));
			h2hdetails.setPosting_id(result.getLong("posting_id"));
			h2hdetails.setArea_business(result.getString("area_business"));
			h2hdetails.setTotal_open_amount(result.getLong("total_open_amount"));
			h2hdetails.setBaseline_create_date(result.getString("baseline_create_date"));
			h2hdetails.setCust_payment_terms(result.getString("cust_payment_terms"));
			h2hdetails.setInvoice_id(result.getLong("invoice_id"));
			h2hdetails.setAging_bucket(result.getString("aging_bucket"));
			h2hdetails.setIs_deleted(result.getLong("is_deleted"));
			
			data.add(h2hdetails);
		}
		con.close();}	
		catch(Exception e) {
		System.out.println(e);
		}
		return data;

}
}
